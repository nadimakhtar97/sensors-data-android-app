package com.example.sensorsdata

data class SensorData(var accX: Float,var accY: Float,var accZ: Float,var gyroX : Float,var gyroY: Float, var gyroZ: Float,var bpm : Float ) {

}

